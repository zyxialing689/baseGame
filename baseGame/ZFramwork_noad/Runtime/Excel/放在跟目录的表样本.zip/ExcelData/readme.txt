目前支持int，long,float,bool,string,stringArray,intArray,floatArray,boolArray,longArray，serv2,serv3,serv4(类似vector2,3,4，因为unity这几个变量不能序列化)
不支持空格（重要）

不能使用&

不用取ALL开头的表格名字
